#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 14:04:46 2020

@author: marshalltekell
"""

from cython_functions_C1 import RDF_p
from cython_functions_C1 import RDF_intra
from cython_functions_C1 import RDF_inter
from cython_functions_C1 import RDF_ca
from cython_functions_C1 import RDF_cb
from cython_functions_C1 import SSF4
from cython_functions_C1 import SSF5
from cython_functions_C1 import VHcb
from cython_functions_C1 import VHcb_log
from cython_functions_C1 import calc_MSD3
from cython_functions_C1 import calc_MSD4
from cython_functions_C1 import calc_MSD3_log
from cython_functions_C1 import calc_MSD4_log


from analysis_functions import update_progress

import numpy as np #python array manipulation package

#%% Pair distribution function class

class RDF:
    
    # Instance of class is created with number of particles, length of box, number of bins, instantaneous position data, density, and mass of specific particle
    def  __init__(self, N, L, nbins, r_int, rho, m, n_t):
        
        self.N = N;
        self.L = L;
        self.nbins = nbins;
        self.r_int = r_int;
        self.rho = rho;
        self.m = m;
        self.n_t = n_t;
        
    # g(r) (can be used for any particle of the same type)
    def RDF0(self):
        
        g = np.zeros((self.nbins))
        
        print('Calculating g(r) (particles of same type).')
        
        for i in range(0,self.n_t):
            
            update_progress(i/self.n_t);
            
            # Get positions for this time step
            r = self.r_int[:,i*3:(i+1)*3];
            
            # Calculate g(r)
            g += RDF_p(self.N, self.L, self.nbins, r, self.rho, self.m);
        
        # Find average
        g = g/self.n_t;
        
        print('Done calculating g(r) (particles of same type).')
        
        return g;
    
    # Polymer g(r) (intra) (receives the number of chains)
    def RDF1(self, M):
        
        g = np.zeros((self.nbins))
        
        print('Calculating g(r) for the polymer beads (intra-chain).')
        
        for i in range(0,self.n_t):
            
            update_progress(i/self.n_t);
            
            # Get positions for this time step
            r = self.r_int[:,i*3:(i+1)*3];
            
            # Calculate g(r)
            g += RDF_intra(self.N, self.L, self.nbins, r, self.rho, self.m, M);
        
        # Find average
        g = g/self.n_t;
        
        print('Done calculating g(r) for the polymer beads (intra-chain).')
        
        return g;
    
    # Polymer g(r) (inter) (receives the number of chains)
    def RDF2(self, M):
        
        g = np.zeros((self.nbins))
        
        print('Calculating g(r) for the polymer beads (inter-chain).')
        
        for i in range(0,self.n_t):
            
            update_progress(i/self.n_t);
            
            # Get positions for this time step
            r = self.r_int[:,i*3:(i+1)*3];
            
            # Calculate g(r)
            g += RDF_inter(self.N, self.L, self.nbins, r, self.rho, self.m, M);
        
        # Find average
        g = g/self.n_t;
        
        print('Done calculating g(r) for the polymer beads (inter-chain).')
        
        return g;
    
    # Cation/anion g(r) 
    def RDF3(self):
        
        g = np.zeros((self.nbins))
        
        print('Calculating g(r) for cation and anion pairs.')
        
        for i in range(0,self.n_t):
            
            update_progress(i/self.n_t);
            
            # Get positions for this time step
            r = self.r_int[:,i*3:(i+1)*3];
            
            # Calculate g(r)
            g += RDF_ca(self.N, self.L, self.nbins, r, self.rho, self.m);
        
        # Find average
        g = g/self.n_t;
        
        print('Done calculating g(r) for cation and anion pairs.')
        
        return g;
    
    # Cation/anion g(r) 
    def RDF4(self, I, r_int):
        
        g = np.zeros((self.nbins))
        
        print('Calculating g(r) for cation and bead pairs.')
        
        for i in range(0,self.n_t):
            
            update_progress(i/self.n_t);
            
            # Get positions for this time step
            rc = self.r_int[:,i*3:(i+1)*3];
            r = r_int[:,i*3:(i+1)*3];
            
            # Calculate g(r)
            g += RDF_cb(I, self.N, self.L, self.nbins, rc, r, self.rho, self.m);
        
        # Find average
        g = g/self.n_t;
        
        print('Done calculating g(r) for cation and bead pairs.')
        
        return g;
    
#%% Static structure factor class
        
class SSF:
    
    def __init__(self, r, N, n_t, q_run, num_p, num_q, L):
        
        self.r = r;
        self.N = N;
        self.n_t = n_t;
        self.q_run = q_run;
        self.num_p = num_p;
        self.num_q = num_q;
        self.L = L;
        
    # Calculate the static structure factor for atoms of the same type
    def SSF0(self):
                
        print('Calculating S(q) (particles of same type).')
        SSQ = SSF4(self.r, self.N, self.n_t, self.q_run, self.num_p, self.num_q, self.L)
        print('Done with calculation.')
        
        return SSQ;
    
    # Calculate the partial static structure factor for atoms of different types.
    
    def SSF1(self, I):
                
        print('Calculating S(q) (particles of different types).')
        SSQ = SSF5(self.r, I, self.N, self.n_t, self.q_run, self.num_p, self.num_q, self.L)
        print('Done with calculation.')
        
        return SSQ;
    
    
#%% van Hove function class

class vanHove:
    
    def __init__(self, r1, r2, I, N, nbins, n_t, L):
        
        self.r1 = r1;
        self.r2 = r2;
        self.I = I;
        self.N = N;
        self.nbins = nbins;
        self.n_t = n_t;
        self.L= L;
    
    # Calculate the van Hove function for linear time sampling    
    def VH0(self, m0, rhop):
        
        # Initialize arrays and variables
        dg = self.L/(2*(self.nbins-1));
        grt = np.zeros((self.nbins,self.n_t));
        
        print('Calculating van Hove function with linear time sampling.')
        print('Printing the sample number.')
        
        # Get van Hove function (missing prefactors)
        G = VHcb(self.r1, self.r2, self.I, self.N, self.nbins, self.n_t, self.L);
        
        print('Done calculating van Hove function with linear time sampling.')
        
        # Use van Hove function to get g(r,t)
        for i in range(0, self.n_t):
            
            for j in range(0, self.nbins):
                
                dV = (1.333)*np.pi*((j+1)**3-j**3)*dg**3;
                grt[j,i] = (G[j,i]*m0*10**24)/(self.n_t*self.I*rhop*dV*6.022*10**(23)); 
                
        return grt;
    
    # Calculate teh van Hove function for multiple loops with a log time sampling
    def VH1(self, m0, rhop, numloop):
        
        # Initialize array
        G = np.zeros((self.nbins,self.n_t));
        dg = self.L/(2*(self.nbins-1));
        grt = np.zeros((self.nbins,self.n_t))
        
        print('Calculating van Hove function with log time sampling.')
        
        update_progress((0)/numloop);
        
        # Loop over the number of runs
        for i in range(0, numloop):
            
            # Get positions for this particular run
            r1_int = self.r1[i*self.N:(i+1)*self.N,:];
            r2_int = self.r2[i*self.I:(i+1)*self.I,:];
            
            # Perform calculation
            G += VHcb_log(r1_int, r2_int, self.I, self.N, self.nbins, self.n_t, self.L);
            
            update_progress((i+1)/numloop);
    
        # Find the average
        G = G/numloop;
        
        # Divide out by the density (get the time dependent pair distribution function)
        for i in range(0,self.n_t):
            
            for j in range(0,self.nbins):
            
                dV = (1.333)*np.pi*((j+1)**3-j**3)*dg**3;
                grt[j,i] = (G[j,i]*m0*10**24)/(self.I*rhop*dV*6.022*10**(23));
                
        return grt;
    
#%% Calculate mean squared and mean quartic displacement

class MSD:
    
    def __init__(self, x, y, z, N, n_t, L):
        
        self.x = x;
        self.y = y;
        self.z = z;
        self.N = N;
        self.n_t = n_t;
        self.L = L;
    
    # Calculate the mean squared displacement    
    def MSD0(self):
        
        print('Calculating mean squared displacement.')
        r, _ = calc_MSD3(self.x, self.y, self.z, self.N, self.n_t, self.L);
        print('Done calculating mean squared displacement.')
        
        return r;
    
    # Calculate the mean quartic displacement
    def MSD1(self):
        
        print("Calculating mean quartic displacement.")
        r, _ = calc_MSD4(self.x, self.y, self.z, self.N, self.n_t, self.L);
        print("Done calculating mean quartic displacement.")
        
        return r;
    
    # Calculate the mean squared displacement for looped log time sampling
    def MSD2(self, numloop):
        
        print("Calculating mean squared displacement.")
        
        # Initialize arrays
        r = np.zeros((self.n_t));
        
        for i in range(0, numloop):
            
            # Initialize arrays
            x_int = np.zeros((self.N,self.n_t));
            y_int = np.zeros((self.N,self.n_t));
            z_int = np.zeros((self.N,self.n_t));
            
            # Get data for this loop
            for j in range(0,self.n_t):
                
                x_int[:,j] = self.x[i*self.N:(i+1)*self.N,j];
                y_int[:,j] = self.y[i*self.N:(i+1)*self.N,j];
                z_int[:,j] = self.z[i*self.N:(i+1)*self.N,j];
            
            
            # Calculate MSD (square)
            r += calc_MSD3_log(x_int, y_int, z_int, self.N, self.n_t, self.L);
                                
        # Find the average
        r = r/numloop;
        print('Done calculating mean squared displacement.')
        
        return r;
    
    # Calculate the mean quartic displacement for looped log time sampling
    def MSD3(self, numloop):
        
        print("Calculating mean quartic displacement.")
        
        # Initialize arrays
        r = np.zeros((self.n_t));
        
        for i in range(0, numloop):
            
            
            x_int = np.zeros((self.N,self.n_t));
            y_int = np.zeros((self.N,self.n_t));
            z_int = np.zeros((self.N,self.n_t));
            
            # Get data for this loop
            for j in range(0,self.n_t):
                
                x_int[:,j] = self.x[i*self.N:(i+1)*self.N,j];
                y_int[:,j] = self.y[i*self.N:(i+1)*self.N,j];
                z_int[:,j] = self.z[i*self.N:(i+1)*self.N,j];
            
            
            # Calculate MSD (square)
            r += calc_MSD4_log(x_int, y_int, z_int, self.N, self.n_t, self.L);
                                
        # Find the average
        r = r/numloop;
        print('Done calculating mean quartic displacement.')
        
        return r;
    
