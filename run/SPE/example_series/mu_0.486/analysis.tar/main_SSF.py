#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 15:06:48 2020

@author: marshalltekell

NVE MD with only Lennard-Jones interactions
"""
# Equation of state of the Lennard-Jones fluid

# Import packages
import numpy as np #python array manipulation package
from analysis_functions import gen_q
from analysis_functions import update_progress

# Import parameters for simulation
from parameters import N, M, I, n_t, mu_mag;
from param_NVT import L;
from classes import SSF

#%% Additional parameters needed for this specific calculation

# Prep for q vectors
dk = (2*np.pi)/L;
low = dk;
high = 5;
q_mag = np.arange(low,high,dk);
num_p = q_mag.shape[0];
num_q = np.zeros((q_mag.shape[0]),dtype=int);
q_run = np.zeros((300,3*num_p));

#%% Load in data from Terremoto zip

data_r = np.load('run_data_r_lammps_ELEC.npz');  # a=r_int, b=x_int, c=y_int,d=z_int
r_int = data_r['a'];
rc_int = data_r['b'];
ra_int = data_r['c'];

r_full = np.concatenate((r_int, rc_int, ra_int));
rcb_int = np.concatenate((rc_int, r_int));
rca_int = np.concatenate((rc_int, ra_int));
rab_int = np.concatenate((ra_int, r_int));


#%% Generate array of q vectors

print('Generating arrays of q vectors for calculation.')

# Loop through the q magnitudes and collect vectors at each mag
for i in range(0, num_p):
    
    update_progress((i+1)/num_p)
    
    q_vec, num_q[i] = gen_q(q_mag[i], L);
        
    # Scan in values to master
    for j in range(0, num_q[i]):
        
        for k in range(0,3):
            
            q_run[j,3*i+k] = q_vec[j,k];
            
print('Done generating vectors.')
        
#%% Create instances of class

## KEY for S(q):
# S0(q) is for the whole system
# S1(q) is for polymer beads
# S2(q) is for cations
# S3(q) is for anions
# S4(q) is for cation/bead pairs
# S5(q) is for cation/anion pairs
# S6(q) is for anion/bead pairs
        
# Create instances
S_q = [];

S_q.append(SSF(r_full, N*M+2*I, n_t, q_run, num_p, num_q, L));
S_q.append(SSF(r_int, N*M, n_t, q_run, num_p, num_q, L));
S_q.append(SSF(rc_int, I, n_t, q_run, num_p, num_q, L));
S_q.append(SSF(ra_int, I, n_t, q_run, num_p, num_q, L));
S_q.append(SSF(rcb_int, N*M, n_t, q_run, num_p, num_q, L));
S_q.append(SSF(rca_int, I, n_t, q_run, num_p, num_q, L));
S_q.append(SSF(rab_int, N*M, n_t, q_run, num_p, num_q, L));

# Initialize g(r) array
S = np.zeros((num_p,len(S_q)));

# Get g(r) for each class instance
S[:,0] = S_q[0].SSF0();
S[:,1] = S_q[1].SSF0();
S[:,2] = S_q[2].SSF0();
S[:,3] = S_q[3].SSF0();
S[:,4] = S_q[4].SSF1(I);
S[:,5] = S_q[5].SSF1(I);
S[:,6] = S_q[6].SSF1(I);

#%% Save to compressed file

np.savez_compressed('SSF_{}_{}_{}_{:.3f}'.format(N, M, I, mu_mag), a=S);