#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 15:06:48 2020

@author: marshalltekell

NVE MD with only Lennard-Jones interactions
"""
# Equation of state of the Lennard-Jones fluid

# Import packages
import numpy as np #python array manipulation package
from mpi4py import MPI

# Import user-defined functions from separate scripts
from cython_functions_C1 import dsf_C_old
from analysis_functions import gen_q

# Import simulation parameters
from parameters import N_steps, p, n_t, N, M, I
from param_NVT import L;

#%% Setup MPI conditions

comm = MPI.COMM_WORLD;
rank = comm.Get_rank();
proc = comm.Get_size();

#%% Additional parameters necessary for calculating F(q,t)

# Time array
time = np.arange(0,N_steps,p);

# Generate q magnitudes
dk = (2*np.pi)/L;
q_mag = [3*dk, 5*dk, 10*dk, 12*dk, 15*dk];

#%% Load in data

data_ru = np.load('run_data_ru_lammps_ELEC.npz');  # a=r_int, b=x_int, c=y_int,d=z_int
ru_int = data_ru['a'];
ruc_int = data_ru['b'];
rua_int = data_ru['c'];

# Initialize arrays
xind = np.arange(0,3*n_t,3);
yind = np.arange(1,3*n_t,3);
zind = np.arange(2,3*n_t,3);

# Polymer
xu_int = ru_int[:,xind];
yu_int = ru_int[:,yind];
zu_int = ru_int[:,zind];

# Cation
xuc_int = ruc_int[:,xind];
yuc_int = ruc_int[:,yind];
zuc_int = ruc_int[:,zind];

# Anion
xua_int = rua_int[:,xind];
yua_int = rua_int[:,yind];
zua_int = rua_int[:,zind];
        
#%% Calculate the self intermediate scattering function


if (rank!=0):
    
    # Generate q vectors at magnitude assigned to processor
    q_vec, num_q = gen_q(q_mag[rank-1], L);
    
    # Initialize Fqt
    Fqt = np.zeros((n_t,3));

    print("Calculating self intermediate scattering function for polymer at q = {:.3f} on process #{:d}.".format(q_mag[rank-1],rank)) 
    Fqt[:,0], count = dsf_C_old(xu_int, yu_int, zu_int, N*M, n_t, L, q_vec, num_q);
    Fqt[:,0] = np.divide(Fqt[:,0], count, out=np.zeros_like(Fqt[:,0]), where=count!=0);
    print('Done with calculation for polymer at q = {:.3f} on processor #{:d}.'.format(q_mag[rank-1],rank));
          
    print("Calculating self intermediate scattering function for cations at q = {:.3f} on process #{:d}.".format(q_mag[rank-1],rank)) 
    Fqt[:,1], count = dsf_C_old(xuc_int, yuc_int, zuc_int, I, n_t, L, q_vec, num_q);
    Fqt[:,1] = np.divide(Fqt[:,1], count, out=np.zeros_like(Fqt[:,1]), where=count!=0);
    print('Done with calculation for cations at q = {:.3f} on processor #{:d}.'.format(q_mag[rank-1],rank));
          
    print("Calculating self intermediate scattering function for anions at q = {:.3f} on process #{:d}.".format(q_mag[rank-1],rank)) 
    Fqt[:,2], count = dsf_C_old(xua_int, yua_int, zua_int, I, n_t, L, q_vec, num_q);
    Fqt[:,2] = np.divide(Fqt[:,2], count, out=np.zeros_like(Fqt[:,2]), where=count!=0);
    print('Done with calculation for anions at q = {:.3f} on processor #{:d}.'.format(q_mag[rank-1],rank));
    
    # Send the total over to the master process
    comm.send(Fqt, dest=0);
    
else:
    
    # Initialize array to hold values at different q mags
    Fqt_t = np.zeros((n_t,3*proc-1));
    
    # Receive the messages and put them in the array
    for i in range(1,proc):
              
        Fqt_t[:,(i-1)*3:i*3] = comm.recv(source=i);
        
    # Save to compressed file
    np.savez_compressed('FQT_{}_{}_{}'.format(N, M, I), a=Fqt_t);
    